#include <stdint.h>

#include "lfsr.h"

void lfsr_calculate(uint16_t *reg) {

    /* VOTRE CODE ICI */

}

