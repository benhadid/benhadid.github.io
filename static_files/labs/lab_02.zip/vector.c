/* Inclusion des entêtes systèmes requises */
#include <stdlib.h>
#include <stdio.h>

/* Inclusion de notre fichier entête */
#include "vector.h"

/* Définition de notre structure  */
struct vector_t {
    size_t size;
    int *data;
};

/* Fonction auxiliaire pour gérer les échecs d'allocation. 
   Dans ce cas, nous imprimons un message et terminons l'exécution. */
static void allocation_failed() {
    fprintf(stderr, "Out of memory.\n");
    exit(1);
}

/* Mauvais exemple de création d'un nouveau vecteur */
vector_t *bad_vector_new() {
    /* Créer le vecteur et un pointeur vers celui-ci */
    vector_t *retval, v;
    retval = &v;

    /* Initialiser les attributs */
    retval->size = 1;
    retval->data = malloc(sizeof(int));
    if (retval->data == NULL) {
        allocation_failed();
    }

    retval->data[0] = 0;
    return retval;
}

/* Une autre façon sous-optimale de créer un vecteur */
vector_t also_bad_vector_new() {
    /* Créer le vecteur */
    vector_t v;

    /* Initialiser les attributs */
    v.size = 1;
    v.data = malloc(sizeof(int));
    if (v.data == NULL) {
        allocation_failed();
    }
    v.data[0] = 0;
    return v;
}

/* Créer un nouveau vecteur d'une taille (longueur) de 1
   et initialiser son composant unique à zéro ...
   LA FAÇON CORRECTE */
vector_t *vector_new() {
    /* Déclarer ce que la fonction doit retourner */
    vector_t *retval;

    /* D'abord, nous devons allouer de la mémoire sur le tas pour la structure */
    retval = // VOTRE CODE ICI

    /* Vérifiez la valeur de retour pour s'assurer que l'allocation de mémoire a réussi */

    if (/* YOUR CODE HERE */) {
        allocation_failed();
    }

    /* Nous devons maintenant initialiser nos données.
       Comme retval->data doit pouvoir croître dynamiquement,
       Qu'avez vous besoin de faire ? */
    retval->size = /* VOTRE CODE ICI */;
    retval->data = /* VOTRE CODE ICI */;

    /* Vérifier l'attribut data du vecteur pour s'assurer que l'allocation de mémoire a réussi */
    if (/* VOTRE CODE ICI */) {
        free(retval);				//Pourquoi cette ligne est nécessaire ?
        allocation_failed();
    }

    /* Terminez l'initialisation en mettant le composant unique à zéro */
    /* VOTRE CODE ICI */ = 0;

    /* retourner la valeur... */
    return retval;
}

/* Renvoie la valeur à l'emplacement / composant "loc" spécifié du vecteur */
int vector_get(vector_t *v, size_t loc) {

    /* Si nous recevons un pointeur NULL pour notre vecteur, signalez-le et arrêtez l'exécution du programme. */
    if(v == NULL) {
        fprintf(stderr, "vector_get: passed a NULL vector.\n");
        abort();
    }

    /* Si l'emplacement demandé est supérieur à la taille que nous avons alloué, renvoyez 0.
     * Sinon, retournez le contenu à l'emplacement spécifié.
     */
    if (loc < /* VOTRE CODE ICI */) {
        return /* VOTRE CODE ICI */;
    } else {
        return 0;
    }
}

/* Libérez la mémoire allouée au vecteur passé en paramètre.
   Rappelons que vous devez libérer TOUTE la mémoire allouée */
void vector_delete(vector_t *v) {
    /* VOTRE SOLUTION ICI */
}


/* Définit une valeur dans le vecteur. Si l'allocation de mémoire échoue, 
   appelez la fonction allocation_failed (). */ 
void vector_set(vector_t *v, size_t loc, int value) {
    /* Que devez-vous faire si l'emplacement est supérieur à la taille que nous 
     * avons allouée ? Rappelons que les emplacements non définis doivent contenir
     * la valeur 0.
     */

    /* VOTRE SOLUTION ICI */
}