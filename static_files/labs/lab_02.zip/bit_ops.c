#include <stdio.h>
#include "bit_ops.h"

// Retourne le n-ième bit de x.
// Vous pouvez considérer que 0 <= n <= 31

unsigned get_bit(uint32_t x,
                 uint8_t n) {
    
    // VOTRE CODE ICI 

    // vous devez aussi modifier 
    // l'instruction "return" ci-dessus.
    // Rappelons que get_bit doit 
    // retourner la valeur 0 ou 1 
    return -1;
}

// Fixe le n-ième bit de la valeur de x à v.
// Vous pouvez considérer que 0 <= n <= 31, et v est soit 0 ou 1
void set_bit(uint32_t * x,
             uint8_t n,
             uint8_t v) {
    
    // VOTRE CODE ICI 

}

// Inverse le n-ième bit de la valeur de x.
// Vous pouvez considérer que 0 <= n <= 31
void flip_bit(uint32_t * x,
              uint8_t n) {
    
    // VOTRE CODE ICI 

}

