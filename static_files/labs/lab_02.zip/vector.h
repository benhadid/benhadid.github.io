#ifndef CS_VECTOR_H_
#define CS_VECTOR_H_

#include <sys/types.h>

/* 
 * Tout d'abord, nous définissons le type de données 'vector_t'. La ligne suivante indique 
 * qu'un 'vector_t' est identique à une 'struct vector_t'. Donc, n'importe où dans le code 
 * après cela, on peut utiliser 'vector_t *' pour désigner un pointeur vers une 'struct vector_t' 
 * (qui est définie dans vector.c).
 */

typedef struct vector_t vector_t;

/* Ensuite, nous fournissons les prototypes des fonctions définies dans vector.c. */
/* YOUR CODE HERE */

/* Créer un nouveau vecteur */
vector_t *vector_new();

/* Libèrer la mémoire allouée au vecteur passé */
/* YOUR CODE HERE */

/* Renvoie la valeur dans le vecteur */
int vector_get(vector_t *v, size_t loc);

/* Définit une valeur dans le vecteur */
/* YOUR CODE HERE */

#endif
