# include<stdint.h>

uint32_t get_bit(uint32_t x, uint8_t n);
void set_bit(uint32_t* x, uint8_t n, uint8_t v);
void flip_bit(uint32_t* x, uint8_t n);