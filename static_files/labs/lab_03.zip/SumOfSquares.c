#include <stdio.h>

unsigned int SumOfSquares(int count, int *tab)
{
  // à compléter
}

int main(int argc,char** argv)
{
	int result = 0;

        int tab [7] = {1, -2, 3, 7, 0, 9, 12};
       
	result = SumOfSquares(7, tab);
      
	if ( result != 288 )
		printf("SumOfSquares returns the wrong value");
        else
		printf("SumOfSquares returns the right value");
}

