#include <math.h>
#include <stdio.h>

float calculatrice(float num1, float num2, char op)
{
 // à compléter
}


int main(int argc,char** argv)
{
        float result;
       
	result = calculatrice(15.0f, 3.0f, '+');
      
        if ( result != 18.0f )
		printf("calculatrice( num1, num2, '+' ) returns the wrong result\n");
}

