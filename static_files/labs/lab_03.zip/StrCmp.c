#include <stdio.h>
#include <string.h>

int StrCmp(char *s1, char *s2)
{
  // à compléter
}


int main(int argc,char** argv)
{
        int result = 0;

        char s1[] = "mi-alger";
        char s2[] = "mi-alger";

        result = StrCmp(s1, s2);
 

        /* test si s1 == s2 */
        if ( result != 0 )
        {
                /*push_info_msg(_("StrCmp returns the wrong value"));*/

                char *errtpl = "StrCmp returne la mauvaise valeur : pour s1 = \"%#2s\" et s2 = \"%#8s\" vous avez returné %d\n";
                char errmsg[strlen(errtpl+30)];

                sprintf(errmsg, errtpl, s1, s2, result);
                printf(errmsg);
        }
        else
        { 
               char *msgtpl = "les chaines de caractères s1 = \"%#2s\" et s2 = \"%#8s\" ont été identifié comme égale\n";
               char  msg[strlen(msgtpl+30)];

               sprintf(msg, msgtpl, s1, s2);
               printf(msg);
        }
}

