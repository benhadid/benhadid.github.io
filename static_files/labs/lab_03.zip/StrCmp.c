#include <stdio.h>
#include <string.h>

int StrCmp(char *s1, char *s2)
{
    /* VOTRE SOLUTION ICI */
}


int main(int argc,char** argv)
{
        int result = 0;

        char s1[] = "mi-alger";
        char s2[] = "mi-alger";

        result = StrCmp(s1, s2);
 

        /* test si s1 == s2 */
        if ( result != 0 )
        {
                char *errtpl = "StrCmp returns a wrong value : for s1 = \"%#2s\" and s2 = \"%#8s\" you have returned %d\n";
                char errmsg[strlen(errtpl+30)];

                sprintf(errmsg, errtpl, s1, s2, result);
                printf(errmsg);
        }
        else
        { 
               char *msgtpl = "The strings s1 = \"%#2s\" and s2 = \"%#8s\" where identified as similar\n";
               char  msg[strlen(msgtpl+30)];

               sprintf(msg, msgtpl, s1, s2);
               printf(msg);
        }
}

