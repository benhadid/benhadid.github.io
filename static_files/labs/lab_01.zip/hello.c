#include <stdio.h>

int main(int argc, char *argv[]) {
    int i;
    int count = 0;
    int *p = &count;

    for (i = 0; i < 10; i++) {
        (*p)++; // Comprenez-vous cette ligne de code et toutes les autres permutations possibles des opérateurs ? ;)
    }

    printf("Thanks for waddling through this program. Have a nice day.");
    return 0;
}