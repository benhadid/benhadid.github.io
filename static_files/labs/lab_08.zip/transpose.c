#include "transpose.h"

/* La fonction de transposition naïve. */
void transpose_naive(int n, int blocksize, int *dst, int *src) {
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            dst[y + x * n] = src[x + y * n];
        }
    }
}

/* Implémentez le cache-blocking ci-dessous. Vous ne devez PAS supposer 
 * que n soit multiple de la taille du bloc blocksize. */
void transpose_blocking(int n, int blocksize, int *dst, int *src) {

    /* VOTRE SOLUTION ICI */

}
