void transpose_naive(int n, int blocksize, int *dst, int *src);
void transpose_blocking(int n, int blocksize, int *dst, int *src);
